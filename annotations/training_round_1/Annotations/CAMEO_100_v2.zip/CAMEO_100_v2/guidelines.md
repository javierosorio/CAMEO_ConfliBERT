### Annotation Guidelines
------
 _Define the team rules of what and how to annotate_


**You can use [markdown syntax](https://commonmark.org/help/)**


----
#### License ⚖️
[Creative Commons: Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/)